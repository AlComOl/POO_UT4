package PruebaPracticaMascarilla;

public interface Interface {


	public int IVA=0;
	
//	metodo
	
	public String toString();
}
